# Besici Pro

Android uygulaması: hayvan takibi, yem maliyeti, ek giderler, kâr planlama, kilo geçmişi ve JSON yedekleme.

## APK oluşturma
GitHub'a bu proje klasörünü yüklediğinde `.github/workflows/build-apk.yml` otomatik olarak APK oluşturur.
GitHub'da **Actions > Besici APK > son çalışma > Artifacts > Besici-Pro-APK** bölümünden `app-debug.apk` alınabilir.

## Özellikler
- Hayvan ekleme, düzenleme, silme ve arama
- Mevcut/ hedef kilo, alış ve tahmini satış hesabı
- Kilo geçmişi
- Yem tanımlama ve günlük maliyet
- Ek gider takibi
- Genel kâr özeti ve rapor
- JSON yedekleme / geri yükleme
- İnternetsiz kullanım
